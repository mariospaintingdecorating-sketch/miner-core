/* tslint:disable */
/* eslint-disable */

export type TParamsOfEnsureMiningKeysPropagated = {
    client_config: Record<string, unknown>;
    miner_address: string;
    app_id: string;
    expected_owner_public: string;
    max_attempts?: number;
    interval_ms?: number;
};

export type TParamsOfGetMinerAddressByWalletName = {
    client_config: Record<string, unknown>;
    wallet_name: string;
};



export class GraphqlBlockData {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    seq_no: bigint;
}

export class Miner {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    add_tap(x: number, y: number): void;
    can_start(): boolean;
    get_current_block(): Promise<GraphqlBlockData>;
    get_miner_data(): Promise<MinerAccountData>;
    get_reward(): Promise<void>;
    static new(endpoints: string[], app_id: string, address: string, public_key: string, secret_key: string): Promise<Miner>;
    remove_seed(seed: string): void;
    start(duration_ms: number, callback: Function): void;
    stop(): void;
}

export class MinerAccountData {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    epoch_5m_start: bigint;
    epoch_start: bigint;
    tap_sum_5m: bigint;
    tap_sum: bigint;
}

export class ResultOfGenMiningKeys {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly deep_link: string;
    readonly public: string;
    readonly secret: string;
}

export function ensure_mining_keys_propagated(params: TParamsOfEnsureMiningKeysPropagated): Promise<void>;

export function gen_mining_keys(app_id: string): Promise<ResultOfGenMiningKeys>;

export function get_miner_address_by_wallet_name(params: TParamsOfGetMinerAddressByWalletName): Promise<string>;

export function start(): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_get_graphqlblockdata_seq_no: (a: number) => bigint;
    readonly __wbg_get_mineraccountdata_epoch_5m_start: (a: number) => bigint;
    readonly __wbg_get_mineraccountdata_epoch_start: (a: number) => bigint;
    readonly __wbg_get_mineraccountdata_tap_sum: (a: number) => [bigint, bigint];
    readonly __wbg_get_mineraccountdata_tap_sum_5m: (a: number) => [bigint, bigint];
    readonly __wbg_graphqlblockdata_free: (a: number, b: number) => void;
    readonly __wbg_miner_free: (a: number, b: number) => void;
    readonly __wbg_mineraccountdata_free: (a: number, b: number) => void;
    readonly __wbg_resultofgenminingkeys_free: (a: number, b: number) => void;
    readonly __wbg_set_graphqlblockdata_seq_no: (a: number, b: bigint) => void;
    readonly __wbg_set_mineraccountdata_epoch_5m_start: (a: number, b: bigint) => void;
    readonly __wbg_set_mineraccountdata_epoch_start: (a: number, b: bigint) => void;
    readonly __wbg_set_mineraccountdata_tap_sum: (a: number, b: bigint, c: bigint) => void;
    readonly __wbg_set_mineraccountdata_tap_sum_5m: (a: number, b: bigint, c: bigint) => void;
    readonly ensure_mining_keys_propagated: (a: any) => any;
    readonly gen_mining_keys: (a: number, b: number) => any;
    readonly get_miner_address_by_wallet_name: (a: any) => any;
    readonly miner_add_tap: (a: number, b: number, c: number) => [number, number];
    readonly miner_can_start: (a: number) => number;
    readonly miner_get_current_block: (a: number) => any;
    readonly miner_get_miner_data: (a: number) => any;
    readonly miner_get_reward: (a: number) => any;
    readonly miner_new: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => any;
    readonly miner_remove_seed: (a: number, b: number, c: number) => void;
    readonly miner_start: (a: number, b: number, c: any) => [number, number];
    readonly miner_stop: (a: number) => void;
    readonly resultofgenminingkeys_deep_link: (a: number) => [number, number];
    readonly resultofgenminingkeys_public: (a: number) => [number, number];
    readonly resultofgenminingkeys_secret: (a: number) => [number, number];
    readonly start: () => void;
    readonly tc_create_context: (a: number) => number;
    readonly tc_destroy_string: (a: number) => void;
    readonly tc_read_string: (a: number, b: number) => void;
    readonly tc_request: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly tc_request_ptr: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly tc_request_sync: (a: number, b: number, c: number) => number;
    readonly tc_destroy_context: (a: number) => void;
    readonly wasm_bindgen_26aa3cd501dd8668___convert__closures_____invoke___js_sys_164efb2d52d7d0dd___Function_fn_wasm_bindgen_26aa3cd501dd8668___JsValue_____wasm_bindgen_26aa3cd501dd8668___sys__Undefined___js_sys_164efb2d52d7d0dd___Function_fn_wasm_bindgen_26aa3cd501dd8668___JsValue_____wasm_bindgen_26aa3cd501dd8668___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen_26aa3cd501dd8668___convert__closures_____invoke___wasm_bindgen_26aa3cd501dd8668___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_26aa3cd501dd8668___JsError___true_: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_26aa3cd501dd8668___convert__closures_____invoke___web_sys_d99b413a2012faf4___features__gen_IdbVersionChangeEvent__IdbVersionChangeEvent__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_26aa3cd501dd8668___JsValue___true_: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_26aa3cd501dd8668___convert__closures_____invoke___wasm_bindgen_26aa3cd501dd8668___JsValue______true_: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen_26aa3cd501dd8668___convert__closures_____invoke___wasm_bindgen_26aa3cd501dd8668___JsValue______true__29: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen_26aa3cd501dd8668___convert__closures_____invoke___wasm_bindgen_26aa3cd501dd8668___JsValue______true__32: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen_26aa3cd501dd8668___convert__closures_____invoke___web_sys_d99b413a2012faf4___features__gen_Event__Event______true_: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen_26aa3cd501dd8668___convert__closures_____invoke_______true_: (a: number, b: number) => void;
    readonly wasm_bindgen_26aa3cd501dd8668___convert__closures_____invoke_______true__1_: (a: number, b: number) => void;
    readonly wasm_bindgen_26aa3cd501dd8668___convert__closures_____invoke_______true__2_: (a: number, b: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
